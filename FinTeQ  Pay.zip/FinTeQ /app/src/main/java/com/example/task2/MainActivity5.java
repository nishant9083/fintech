package com.example.task2;

import android.app.Activity;

public class MainActivity5 extends Activity {
}
